
#include "ros/ros.h"
#include "stdio.h"
#include <geometry_msgs/TwistStamped.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/UInt8.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/BatteryState.h>
#include "tf/transform_datatypes.h"
#include "Lidar3I.hpp"
#include "Motion3I.hpp"

class Robot
{
private:
    /* data */

    ros::NodeHandle    m_nh;
    ros::Subscriber    m_sub_base_cmd;
    ros::Subscriber    m_sub_joy;
    ros::Publisher     m_pub_base_cmd;
    ros::Publisher     m_pub_wheel_odom;
    ros::Publisher     m_pub_bumper;
    ros::Publisher     m_laser_pub;
    ros::Publisher     m_cloud_pub;
    ros::Publisher     m_battery_pub;

    sensor_msgs::LaserScan scan;

    void subCallbackBaseCmd(const geometry_msgs::Twist::ConstPtr &in)
    {
        Motion3I::Velocity_t vel;
        vel.x_vel = in->linear.x;
        vel.y_vel = 0;
        vel.yaw_vel = in->angular.z;
        motion->SetVelocit(vel);
    }

    void subCallbackJoy(const sensor_msgs::Joy::ConstPtr &in)
    {
        geometry_msgs::Twist  base_cmd;
        static bool safety = 0;

        if(safety != in->buttons[4])
        {
            safety = !safety;
        }
        if(safety)
        {
            base_cmd.linear.x = in->axes[1] * 0.3;
            base_cmd.linear.y = in->axes[0] * 0.3;
            base_cmd.linear.z = 0;
            base_cmd.angular.x = 0;
            base_cmd.angular.y = 0;
            base_cmd.angular.z = in->axes[3] * 0.5;
            m_pub_base_cmd.publish(base_cmd);
        }
        else
        {
            base_cmd.linear.x = 0;
            base_cmd.linear.y = 0;
            base_cmd.linear.z = 0;
            base_cmd.angular.x = 0;
            base_cmd.angular.y = 0;
            base_cmd.angular.z = 0;
            m_pub_base_cmd.publish(base_cmd);
        }
    }

    void pubWheelOdom()
    {
        nav_msgs::Odometry     odom;
        Motion3I::Velocity_t vel;
        Motion3I::Position_t get_pos;

        motion->GetVelocit(vel);
        motion->GetOdometer(get_pos);

        odom.header.frame_id   = "odom";
        odom.child_frame_id    = "base_link";
        odom.header.stamp      = ros::Time::now();

        odom.twist.twist.linear.x  = vel.x_vel;
        odom.twist.twist.linear.y  = vel.y_vel;
        odom.twist.twist.angular.z = vel.yaw_vel;
        odom.pose.pose.position.x  = get_pos.x;
        odom.pose.pose.position.y  = get_pos.y;
        odom.pose.pose.position.z  = 0.0;
        odom.pose.pose.orientation = tf::createQuaternionMsgFromYaw(get_pos.yaw);
        odom.twist.covariance[0]   = 0.0025 * abs(odom.twist.twist.linear.x);
        odom.twist.covariance[7]   = 0.0025 * abs(odom.twist.twist.linear.y);
        odom.twist.covariance[35]  = 0.0025 * abs(odom.twist.twist.angular.z);
        m_pub_wheel_odom.publish(odom);
    };

    void pubBumper()
    {
        std_msgs::UInt8 bumper;
        uint8_t left,right;
        motion->GetBumper(left,right);
        bumper.data = left << 1 & right;
        m_pub_bumper.publish(bumper);
    }

    void PublishCloud()
    {
        sensor_msgs::PointCloud cloud;
    }

    void PublishLaserScanFan()
    {
        Lidar3I::LidarPoint lidar_point;
        static uint16_t angle = 0;
        std::queue<Lidar3I::LidarPoint> &laser_scan = lidar->getLaserScan();

        while(!laser_scan.empty())
        {
            lidar_point = laser_scan.front();
            laser_scan.pop();
            if(lidar_point.angle >= angle)
            {
                scan.intensities.push_back(lidar_point.signal );
                scan.ranges.push_back(lidar_point.distance / 10000.0);
            }
            else
            {
                int num = scan.ranges.size();
                scan.header.frame_id = "horizontal_laser_link";
                scan.header.stamp    = ros::Time::now();

                scan.angle_min       = 0;
                scan.angle_max       = 6.28;
                scan.angle_increment = (6.28 / (num - 1));
                scan.time_increment  = 0.0;//(1.0 / (6 *  num));//(1 / hz)
                scan.scan_time       = 0.0;//(scan.time_increment * 360);
                scan.range_min       = 0.1;
                scan.range_max       = 5.0;
                m_laser_pub.publish(scan);
                scan.intensities.clear();
                scan.ranges.clear();
                scan.intensities.push_back(lidar_point.signal );
                scan.ranges.push_back(lidar_point.distance / 10000.0);
                printf("%f \r\n",lidar->GetSpeed().first);
            }
            angle = lidar_point.angle;
        }
    }

    void pubBatteryState()
    {
        static int time = 0;
        if(time++ > 100)
        {
            time = 0;
            sensor_msgs::BatteryState battery;
            uint8_t voltage,state;
            motion->GetBattery(voltage,state);
            battery.voltage = voltage / 10.0;
            battery.charge  = state;
            m_battery_pub.publish(battery);
        }
    }

    Lidar3I       *lidar;
    Motion3I      *motion;
public:

    Robot(/* args */)
    :lidar(new Lidar3I()),
    motion(new Motion3I())
    {

    }

    ~Robot()
    {
        delete(lidar);
        delete(motion);
    }

    void Init()
    {
        lidar->Init();
        motion->Init();

        m_sub_base_cmd          = m_nh.subscribe("/base_cmd", 1, &Robot::subCallbackBaseCmd,this);
        m_sub_joy               = m_nh.subscribe("/joy", 1, &Robot::subCallbackJoy,this);

        m_pub_base_cmd          = m_nh.advertise<geometry_msgs::Twist>("/base_cmd", 50);
        m_pub_wheel_odom        = m_nh.advertise<nav_msgs::Odometry>("/odom", 2);
        m_pub_bumper            = m_nh.advertise<std_msgs::UInt8>("/bumper",1);
        m_cloud_pub             = m_nh.advertise<sensor_msgs::PointCloud>("/cloud", 50);
        m_laser_pub             = m_nh.advertise<sensor_msgs::LaserScan>("/horizontal_laser_2d", 50);
        m_battery_pub           = m_nh.advertise<sensor_msgs::BatteryState>("/battery", 1);

        lidar->SetMode(1);
        motion->SetMode(1);
    }

    void Run()
    {
        lidar->Run();
        motion->Run();

        pubWheelOdom();
        pubBumper();
        PublishLaserScanFan();
        pubBatteryState();

        ros::spinOnce();
    }
};

#include <signal.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
    ros::init(argc, argv, "robot3i_node");
    ros::start();

    ros::Rate  m_loopRate(100);
    Robot *rebot   = new Robot();

    ros::NodeHandle n;
    rebot->Init();
    while(ros::ok())
    {
        rebot->Run();
        m_loopRate.sleep();
    }
    delete(rebot);
    sleep(1);
    return 0;
}
