//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� framegrabber.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_DLG_SERIAL_SEL              201
#define IDC_COMB_SERIAL_SEL             1000
#define ID_CMD_GRAB_FRAME               32776
#define ID_CMD_SCAN                     32780
#define ID_CMD_GRAB_PEAK                32781
#define ID_COMMAND_STARTGRABFRAME       32782
#define ID_COMMAND_SCAN                 32783
#define ID_COMMAND_GRABPEAK             32784
//#define ID_CMD_RESET                    32785
//#define ID_COMMAND_RESET                32786
#define ID_COMMAND_GETCALIBRATIONINFO   32787
#define ID_CMD_                         32788
#define ID_CMD_STOP                     32790
#define ID_COMMAND_STOP                 32791
//#define ID_OPTION_FORCESCAN             32793
//#define ID_OPT_FORCESCAN                32794
//#define ID_FILE_DUMPDATA                32795
#define ID_COMMAND_GRABFRAMENONEDIFF    32797
#define ID_CMD_GRABFRAMENONEDIFF        32798

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
